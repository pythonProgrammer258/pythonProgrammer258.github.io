# pythonGame
I create a python 2d game
To open this you must have installed python and libraries pygame and time.
To get this libraries type: <br />
<img src = "to_readme/pygame.png"><br />
and <br />
<img src = "to_readme/time.png" /> <br />
<br />
<h3>Have fun</h3>
